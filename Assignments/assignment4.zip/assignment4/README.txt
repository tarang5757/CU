Name: Tarang Patel
student number: 101249181

Files:
Album: The Album class represents a photo album that stores photos in a dynamic array with functions to add remove and display photos
AlbumArray: This class represents an array of pointers to Album objects with methods to add, retrieve, and remove Albums in sorted order by title
Photo: class represents a photo with a title, date, and content, and provides methods for printing and displaying the photo
Photo objects from the array
PhotoGram: A photogram class with methods for adding, removing, displaying, and printing photo albums and individual photos.
Array: implements an array of pointers to Photo objects with methods to add, get, and remove photos
Criteria: Criteria class that defines virtual functions to filter photos based on category and date and a friend overloaded operator function for printing the criteria.
Array: templated class for an array data structure that basically provides methods for adding, removing, and getting elements, as well as overloading operators for addition and subtraction.





compilation:open the terminal in the directory and type "make a4" it should compile all the files and make an executable called "a4". Assuming that you are in the same directory do "./a4".


